/**
 * 
 */
/**
 * @author profesor
 *
 */
module actividad3 {
	requires java.sql;
}