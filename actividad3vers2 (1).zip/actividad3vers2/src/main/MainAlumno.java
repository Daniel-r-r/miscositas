package main;

public class MainAlumno {
	
	/*
	 * METODO MAIN DE LA APLICACIÓN
	 */
	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.init();
	}

}
